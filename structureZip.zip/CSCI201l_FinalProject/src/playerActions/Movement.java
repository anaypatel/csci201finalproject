package playerActions;

public class Movement 
{
	private int playerID;
	private int x, y;
	
	public Movement(int _playerID, int _x, int _y)
	{
		this.playerID = _playerID;
		this.x = _x;
		this.y = _y;
	}
	

}
